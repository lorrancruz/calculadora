# Calculadora de média #AULA1 #ALURA #EXTRA

A Pen created on CodePen.io. Original URL: [https://codepen.io/lorrancruz/pen/mdLJdmO](https://codepen.io/lorrancruz/pen/mdLJdmO).

