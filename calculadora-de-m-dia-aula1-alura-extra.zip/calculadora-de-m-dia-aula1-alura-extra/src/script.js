var nome = "Lorran"

var notaDoPrimeiroBimestre = 9
var notaDoSegundoBimestre = 10
var notaDoTerceiroBimestre = 8
var notaDoQuartoBimestre = 7

var notaFinal = (notaDoPrimeiroBimestre + notaDoSegundoBimestre + notaDoTerceiroBimestre + notaDoQuartoBimestre) / 4

var notaFixada = notaFinal.toFixed(1)

console.log("Bem vindo " + nome)
console.log(notaFixada)

//REVISÃO AULA 1
//variaveis, string, console.log, toFixed, operações matematicas, concatenação 

